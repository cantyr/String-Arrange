// main.cpp

// Author: Ryan Canty

// Date: 10/21/15

// Course: CSC1610

// Description: This file takes three user-inputted strings, prompts them for a
// selection to rearrange the strings, and outputs the rearranged strings to the
// user.

// Input: Three user-defined strings collected from the standard input stream
// (keyboard).

// Output: The rearranged strings.


#include <cstdlib>
#include <iostream>
#include <cmath>
#include <cassert>
#include <string>
#include <string.h>

using namespace std;

bool getMin( string, string );
bool getMax( string, string );
bool getMin( int, int );
bool getMax( int, int );
string alphabetize( string, string, string, int );
string byLength( string, string, string, int );
string rearrange( string, string, string, int );
string order( string, string, string );
string sameLength( string, string, string );

/*
 * 
 */
int main() {
    
    string userString1; //First user-inputted string
    string userString2; //Second user-inputted string
    string userString3; //Third user-inputted string
    cout << "Please input three strings: " << endl; //Prompt for strings
    cin >> userString1 >> userString2 >> userString3; //Store strings
    cout << " " << endl; //Blank line
    
    int select1 = 1; //Integer that represents first selection
    int select2 = 2; //Integer that represents second selection
    int select3 = 3; //Integer that represents third selection
    int select4 = 4; //Integer that represents fourth selection
    int selection; //Integer that will hold the user response.
    
    cout << select1 << " - Listed alphabetically, earliest to latest" << endl;
    cout << select2 << " - Listed alphabetically, latest to earliest" << endl;
    cout << select3 << " - Listed length, shortest to longest" << endl;
    cout << select4 << " - Listed length, longest to shortest" << endl;
    //Creates an interface for the user to work with.
    cin >> selection; //Take in the user selection
   
    cout << rearrange( userString1, userString2, userString3, selection ) << endl;

    return 0;
}

bool getMin( string s1, string s2)
{
    return s1 < s2;
}
bool getMax( string s1, string s2 )
{
    return s1 > s2;
}
bool getMin( int n1, int n2 )
{
    return n1 <= n2;
}
bool getMax( int n1, int n2 )
{
    return n1 >= n2;
}

string order( string s1, string s2, string s3 )
{
    return s1 + ' ' + s2 + ' ' + s3;
}

string sameLength( string s1, string s2, string s3 )
{
    if(s1.length() == s2.length() && s2.length() == s3.length())
    {
        if(getMin(s1, s2) && getMin(s1, s3) && getMin(s2, s3))
        {
            return order( s1, s2, s3 );
        }
        else if(getMin(s1, s2) && getMin(s1, s3) && getMin(s3, s2))
        {
            return order( s1, s3, s2 );
        }
        else if(getMin(s2, s1) && getMin(s2, s3) && getMin(s1, s3))
        {
            return order( s2, s1, s3 );
        }
         else if(getMin(s2, s1) && getMin(s2, s3) && getMin(s3, s1))
        {
            return order( s2, s3, s1 );
        }
        else if(getMin(s3, s1) && getMin(s3, s2) && getMin(s1, s2))
        {
            return order( s3, s1, s2 );
        }
        else
            return order( s3, s2, s1 );
    }
    else
        return order( s1, s2, s3);
}

string alphabatize( string s1, string s2, string s3, int check )
{
    if(check == 1)
    {
        if(getMin(s1, s2) && getMin(s1, s3) && getMin(s2, s3))
        {
            return order( s1, s2, s3 );
        }
        else if(getMin(s1, s2) && getMin(s1, s3) && getMin(s3, s2))
        {
            return order( s1, s3, s2 );
        }
        else if(getMin(s2, s1) && getMin(s2, s3) && getMin(s1, s3))
        {
            return order( s2, s1, s3 );
        }
         else if(getMin(s2, s1) && getMin(s2, s3) && getMin(s3, s1))
        {
            return order( s2, s3, s1 );
        }
        else if(getMin(s3, s1) && getMin(s3, s2) && getMin(s1, s2))
        {
            return order( s3, s1, s2 );
        }
        else
            return order( s3, s2, s1 );
        
        
    }
    else if(check == -1)
    {
       if(getMax(s1, s2) && getMax(s1, s3) && getMax(s2, s3))
        {
            return order( s1, s2, s3 );
        }
        else if(getMax(s1, s2) && getMax(s1, s3) && getMax(s3, s2))
        {
            return order( s1, s3, s2 );
        }
        else if(getMax(s2, s1) && getMax(s2, s3) && getMax(s1, s3))
        {
            return order( s2, s1, s3 );
        }
         else if(getMax(s2, s1) && getMax(s2, s3) && getMax(s3, s1))
        {
            return order( s2, s3, s1 );
        }
        else if(getMax(s3, s1) && getMax(s3, s2) && getMax(s1, s2))
        {
            return order( s3, s1, s2 );
        }
        else
            return order( s3, s2, s1 );
    }
}

string byLength( string s1, string s2, string s3, int check )
{
    int s1Length = s1.length();
    int s2Length = s2.length();
    int s3Length = s3.length();
    
    if(check == 1)
    {
        if(getMin(s1Length, s2Length) && getMin(s1Length, s3Length) && getMin(s2Length, s3Length))
        {
            return sameLength(s1, s2, s3);
        }
        else if(getMin(s1Length, s2Length) && getMin(s1Length, s3Length) && getMin(s3Length, s2Length))
        {
            return order( s1, s3, s2 );
        }
        else if(getMin(s2Length, s1Length) && getMin(s2Length, s3Length) && getMin(s1Length, s3Length))
        {
            return order( s2, s1, s3 );
        }
         else if(getMin(s2Length, s1Length) && getMin(s2Length, s3Length) && getMin(s3Length, s1Length))
        {
            return order( s2, s3, s1 );
        }
        else if(getMin(s3.length(), s1.length()) && getMin(s3.length(), s2.length()) && getMin(s1.length(), s2.length()))
        {
            return order( s3, s1, s2 );
        }
        else
            return order( s3, s2, s1 );
    }
    else if(check == -1)
    {
        if(getMax(s1Length, s2Length) && getMax(s1Length, s3Length) && getMax(s2Length, s3Length))
        {
            return sameLength(s1, s2, s3);
        }
        else if(getMax(s1Length, s2Length) && getMax(s1Length, s3Length) && getMax(s3Length, s2Length))
        {
            return order( s1, s3, s2 );
        }
        else if(getMax(s2Length, s1Length) && getMax(s2Length, s3Length) && getMax(s1Length, s3Length))
        {
            return order( s2, s1, s3 );
        }
         else if(getMax(s2Length, s1Length) && getMax(s2Length, s3Length) && getMax(s3Length, s1Length))
        {
            return order( s2, s3, s1 );
        }
        else if(getMax(s3.length(), s1.length()) && getMax(s3.length(), s2.length()) && getMax(s1.length(), s2.length()))
        {
            return order( s3, s1, s2 );
        }
        else
            return order( s3, s2, s1 );
    }
}

string rearrange( string s1, string s2, string s3, int selection )
{
    
    
    switch(selection)
    {
        case 1:
        {
            return alphabatize( s1, s2, s3, 1 );
        }
        case 2:
        {
            return alphabatize(  s1, s2, s3, -1 );
        }
        case 3:
        {
            return byLength( s1, s2, s3, 1 );
        }
        case 4: 
        {
            return byLength( s1, s2, s3, -1 );
        }
    }
}

/*if(s1 < s2 && s1 < s3 && s2 < s3)
            return s1 + ' ' + s2 + ' ' + s3;
        else if( s1 < s2 && s1 < s3 && s3 < s2)
            return s1 + ' ' + s3 + ' ' + s2;
        else if(s2 < s1 && s2 < s3 && s1 < s3)
            return s2 + ' ' + s1 + ' ' + s3;
        else if(s2 < s1 && s2 < s3 && s3 < s1)
            return s2 + ' ' + s3 + ' ' + s1;
        else if(s3 < s1 && s3 < s2 && s2 < s1)
            return s3 + ' ' + s2 + ' ' + s1;
        else if(s3 < s1 && s3 < s2 && s1 < s2)
            return s3 + ' ' + s1 + ' ' + s2;*/